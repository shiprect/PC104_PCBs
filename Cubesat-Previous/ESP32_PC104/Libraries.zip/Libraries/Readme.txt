Connector_Coaxial.pretty - contains footprint for SMA
HX1.pretty - footprint and symbols for HX1 Radiometrix (custom made)
LIB_ESP32_PICO_D4 - footprint and symbol I think (honestly im not 
			entirely sure how since its just a .lib file but it works)
OM-7604-C7-32.768kHz - footprint (from snapeda) and symbol (custom made)
SMA - sma connector symbol